# @yueli/content-nuxt

Foundation 所有的内容工具 Nuxt layer，向 Blog、Docs、Resource、Shop 等内容站共享富 Markdown 编辑器和
阅读端渲染器。它不调用站点接口；消费应用通过 `image-uploader` adapter 提供上传，通过自己的领域流程保存正文。

## 模块边界

- 外部接口是 `<ContentEditor>` 与 `<ContentProse>`；默认阅读样式由 Nuxt layer 自动加载。
- Markdown 渲染器、Tiptap 编辑器扩展、Mermaid 图表渲染器和本地草稿属于模块内部实现，
  不拆成要求消费者重新组合的浅包。
- 产品拥有文章、商品和资源条目的数据结构、权限、发布生命周期与远程保存；本模块只拥有通用内容行为。

## 自动导入内容

| 组件              | 用途                                                                                                    | 接口                                                                                                                          |
| ----------------- | ------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| `<ContentEditor>` | 完整富文本 Markdown 编辑器，支持代码高亮、数学公式、Mermaid、提示块、表情、拖拽手柄和草稿自动保存。     | `v-model` 为 Markdown 字符串；属性包括 `image-uploader`、`draft-entity-id`、`has-initial-content`；ref 方法为 `markSaved()`。 |
| `<ContentProse>`  | 使用 marked、KaTeX、highlight.js、Mermaid 与 marked-alert 渲染相同 Markdown，使用隔离的 `Marked` 实例。 | `content: string`。                                                                                                           |

消费应用扩展该 layer 后可直接在模板使用两个组件，无需显式导入。

## 接入方式

1. 在应用 `package.json` 增加工作区依赖：

   ```json
   { "dependencies": { "@yueli/content-nuxt": "<正式 Release URL>" } }
   ```

2. 在 `nuxt.config.ts` 扩展 layer：

   ```ts
   export default defineNuxtConfig({
     extends: ["@yueli/identity-nuxt", "@yueli/content-nuxt"],
   });
   ```

3. 直接使用组件。layer 自动启用 Foundation UI 的样式集成，并登记正文样式与 KaTeX CSS；Typography 由共享 UI 自动提供，应用无需导入 `article.css` 或手工启用插件。产品可在自己的 CSS 中配置主题变量及额外内容样式。

## Layer 已统一处理的事项

消费者不得重复声明以下配置；Nuxt `extends` 会合并本 layer 的 `nuxt.config`：

- **ProseMirror 单实例去重**：`vite.optimizeDeps.include` 强制直接导入的 `@tiptap/*` 扩展与 `@nuxt/ui` 内置 Tiptap 共享同一 ProseMirror，避免 `Adding different instances of a keyed plugin`。
- **KaTeX 样式**：全局引入 `katex/dist/katex.min.css`，同时覆盖阅读器和编辑器公式预览。
- **隔离 marked**：`<ContentProse>` 使用私有 `new Marked()`，不会污染 `@nuxt/ui` 编辑器解析器。

Foundation UI 把默认样式、layer 样式与产品 CSS 组织在同一个编译入口中，统一处理 Typography 与默认阅读规则；消费者不承担内部导入顺序。原 `article.css` 导出保留供旧工具识别，新 Nuxt 接入不使用它。

## 离线与依赖

- 本层会启用 `@nuxt/ui`，消费应用必须提供满足版本范围的对等依赖，因为 `useEditorToolbar` 在运行时导入
  `@nuxt/ui/utils/editor`。
- 可离线使用：Tabler 图标、KaTeX 与 highlight.js 样式都随 `article.css` 提供，不依赖 CDN。
- Tiptap 支持 `3.27.0` 起的同一主版本，并由消费应用 lock 与 `@nuxt/ui` 统一选择具体 patch；Foundation
  当前以 `3.28.0` 验证。同时携带 `@tiptap/pm` 与表情菜单所需的 `@tiptap/suggestion`，不把编辑器内部
  peer 留给消费应用补齐。

验证：

```text
pnpm --filter @yueli/content-nuxt test
pnpm --filter @yueli/content-nuxt typecheck
pnpm --filter @yueli/content-nuxt pack --dry-run
```

## Images and document import

ContentEditor uses the existing imageUploader(File) adapter for its multi-image dialog and direct editor paste/drop. The dialog supports file selection, drag/drop, clipboard input, progress and retryable errors.

The import action accepts Markdown, HTML, DOCX, or one document plus its images in a ZIP; rich HTML can also be pasted into the dialog. Imported HTML is sanitized and image references are resolved/uploaded before the content is inserted at the cursor. Existing content is preserved. Missing files or unreadable cross-origin images keep the dialog open for correction. Remote image reads use browser CORS; there is no server-side fetch proxy. DOCX imports semantic content supported by the editor rather than page-layout fidelity.

外链图片导入会尝试下载；读取或上传失败后保留带原图链接的文字占位，并继续导入正文与其他图片。

## 可配置图片交互（0.2.6 预览）

默认保留多图导入能力，普通发帖可设置 `image-multiple=false`：文件选择/拖入/粘贴一次一张，拒绝批量而不静默丢图。`image-picker(): Promise<File|null>` 提供单图选择；`image-processor(File): Promise<File|null>` 在直接图片上传前处理裁剪，null 取消且不插入；`image-editor({src,alt}): Promise<File|null>` 给已选图片添加“编辑图片”气泡入口，处理后复用 uploader 替换原节点。文档导入保留独立批量语义。

产品只接入媒体裁剪和上传 Adapter；取消不改正文，异步返回核对原图片节点，不覆盖已删除/替换的图片。

## 2026-10-13 单图上传面板

默认图片入口继续使用 ContentImportDialog，提供点击选择、拖入和粘贴、预览及确认上传。image-multiple=false 只限制张数，不绕过面板。image-processor 同时提供面板预览的可选“编辑图片”动作；取消保留待上传图片，编辑后回到面板，确认上传不再重复裁剪。直接向编辑器粘贴/拖入仍可用 processor。尺寸、编码和质量优先由 Asset 已注册派生策略执行，消费方不得写死第二套限制。

### Batch image processor (workbench preview)

Selection and image bubbles attach to the document body so sticky toolbars and editor overflow containers cannot obscure their controls.

Optional `imageBatchProcessor(files): Promise<File[] | null>` prepares editor drop/paste/picker images in one shared dialog; returning null cancels insertion. It supersedes the per-file processor for those inputs. `imagePicker` may now return File or File[]. `imageProcessor` remains the single-image edit adapter. Consumers may mark already-processed picker files to bypass a second preparation. `imageLimit` caps total image nodes including imported documents; validation runs inside the upload queue before uploads. Existing consumers without these props keep their behavior. Backend limits remain product-owned.
